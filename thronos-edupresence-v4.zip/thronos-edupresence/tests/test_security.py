import time
from app.security import sign_payload, verify_token

def test_signed_token_roundtrip():
    token = sign_payload({"typ": "student_checkin", "attendance_id": 1, "exp": int(time.time()) + 60})
    payload = verify_token(token, expected_type="student_checkin")
    assert payload["attendance_id"] == 1

def test_wrong_type_fails():
    token = sign_payload({"typ": "student_checkin", "attendance_id": 1, "exp": int(time.time()) + 60})
    try:
        verify_token(token, expected_type="teacher_scan")
        assert False
    except Exception:
        assert True
